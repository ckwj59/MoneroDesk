#ifndef MONERODESK_MATRIX_H
#define MONERODESK_MATRIX_H
/* Distance loops use unsigned indices; validate both index and byte ranges. */
#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
static __hwloc_inline size_t
hwloc_safe_matrix_bytes(size_t count, size_t width)
{
  size_t cells;
  if (!count || !width || count > UINT_MAX / count) {
    errno = EINVAL;
    return 0;
  }
  cells = count * count;
  if (cells > SIZE_MAX / width) {
    errno = ENOMEM;
    return 0;
  }
  return cells * width;
}

static __hwloc_inline void *
hwloc_safe_matrix_alloc(size_t count, size_t width)
{
  size_t bytes = hwloc_safe_matrix_bytes(count, width);
  return bytes ? malloc(bytes) : NULL;
}

#endif
