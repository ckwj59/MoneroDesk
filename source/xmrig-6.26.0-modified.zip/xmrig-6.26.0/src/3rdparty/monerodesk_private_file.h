/* MoneroDesk: create new private files without permissive-creation races.
 * Existing files are deliberately not overwritten, including symlinks. */
#ifndef MONERODESK_PRIVATE_FILE_H
#define MONERODESK_PRIVATE_FILE_H
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <windows.h>
#include <sddl.h>
#include <io.h>
#include <stdint.h>
#else
#include <unistd.h>
#endif
static FILE *monerodesk_private_file(const char *path)
{
    int fd;
    FILE *file;
#ifdef _WIN32
    PSECURITY_DESCRIPTOR sd = NULL;
    SECURITY_ATTRIBUTES sa;
    HANDLE handle;
    /* Protected DACL: SYSTEM and the owner only. */
    if (!ConvertStringSecurityDescriptorToSecurityDescriptorA(
            "D:P(A;;FA;;;SY)(A;;FA;;;OW)", SDDL_REVISION_1, &sd, NULL))
        return NULL;
    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = sd;
    sa.bInheritHandle = FALSE;
    handle = CreateFileA(path, GENERIC_WRITE, 0, &sa, CREATE_NEW,
                         FILE_ATTRIBUTE_NORMAL, NULL);
    LocalFree(sd);
    if (handle == INVALID_HANDLE_VALUE) return NULL;
    fd = _open_osfhandle((intptr_t)handle, _O_WRONLY | _O_BINARY);
    if (fd < 0) { CloseHandle(handle); return NULL; }
    file = _fdopen(fd, "wb");
    if (!file) _close(fd);
#else
    fd = open(path, O_WRONLY | O_CREAT | O_EXCL, S_IRUSR | S_IWUSR);
    if (fd < 0) return NULL;
    file = fdopen(fd, "wb");
    if (!file) close(fd);
#endif
    return file;
}
#endif
